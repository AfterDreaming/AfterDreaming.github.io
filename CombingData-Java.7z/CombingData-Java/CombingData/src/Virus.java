
public class Virus {
    private String Sequence_ID;
    private String Symptoms;
    private String Mortality;
    private String Complications;
    private String Drug_Resistance;
    private String At_Risk_Vulnerability;
    private String sequences;
    public Virus() {
        super();
    }
    public Virus(String sequence_ID, String symptoms, String mortality, String complications, String drug_Resistance,
            String at_Risk_Vulnerability, String sequences) {
        super();
        Sequence_ID = sequence_ID;
        Symptoms = symptoms;
        Mortality = mortality;
        Complications = complications;
        Drug_Resistance = drug_Resistance;
        At_Risk_Vulnerability = at_Risk_Vulnerability;
        this.sequences = sequences;
    }
    public String getSequence_ID() {
        return Sequence_ID;
    }
    public void setSequence_ID(String sequence_ID) {
        Sequence_ID = sequence_ID;
    }
    public String getSymptoms() {
        return Symptoms;
    }
    public void setSymptoms(String symptoms) {
        Symptoms = symptoms;
    }
    public String getMortality() {
        return Mortality;
    }
    public void setMortality(String mortality) {
        Mortality = mortality;
    }
    public String getComplications() {
        return Complications;
    }
    public void setComplications(String complications) {
        Complications = complications;
    }
    public String getDrug_Resistance() {
        return Drug_Resistance;
    }
    public void setDrug_Resistance(String drug_Resistance) {
        Drug_Resistance = drug_Resistance;
    }
    public String getAt_Risk_Vulnerability() {
        return At_Risk_Vulnerability;
    }
    public void setAt_Risk_Vulnerability(String at_Risk_Vulnerability) {
        At_Risk_Vulnerability = at_Risk_Vulnerability;
    }
    public String getSequences() {
        return sequences;
    }
    public void setSequences(String sequences) {
        this.sequences = sequences;
    }
}
