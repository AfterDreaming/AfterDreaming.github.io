
public class Strain {
    private String id;
    private String sequences;
    public Strain(String id, String sequences) {
        super();
        this.id = id;
        this.sequences = sequences;
    }
    
   public Strain(){
       
   }

public String getId() {
    return id;
}

public void setId(String id) {
    this.id = id;
}

public String getSequences() {
    return sequences;
}

public void setSequences(String sequences) {
    this.sequences = sequences;
} 
   
   
}
