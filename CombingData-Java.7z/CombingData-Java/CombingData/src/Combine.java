import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

public class Combine {
    public static void main(String[] args){
        Combine c = new Combine();
        ArrayList<DiseaseCharacteristic> list1 = c.readDisease("data/DiseaseCharacteristics.tsv");
        ArrayList<Strain> list2 = c.readStrain("data/strains.json");
        ArrayList<Virus> list3 = c.combiningData(list1, list2);
        c.outputVirusData("data/data.json",list3);
        c.outputSameColumns("data/NotSameColumns.json",list2);
        c.outPutStrainEmitted("data/strainEmitted.json", list2);
    }
    
    //tsv file
    /**
     * @param filename
     * @return
     */
    public ArrayList<DiseaseCharacteristic> readDisease(String filename){
        ArrayList<DiseaseCharacteristic> result = new ArrayList<DiseaseCharacteristic>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(new File(filename)));
            
            String s = reader.readLine();
            while( (s = reader.readLine()) != null){
                String[] list = s.split("\t");
/*                for(String token:list){
                    System.out.print(token);
                }
                System.out.println();*/
                result.add(new DiseaseCharacteristic(
                        list[0],list[1],list[2],list[3],list[4],list[5]
                        ));
            }
            
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return result;
    }
    
    //json file
    public ArrayList<Strain> readStrain(String filename){
        ArrayList<Strain> result = new ArrayList<Strain>();
        StringBuffer content = new StringBuffer("");
        try {
            BufferedReader reader = new BufferedReader(new FileReader(new File(filename)));
            String s;
            while( (s = reader.readLine()) != null){
                content.append(s);
            }
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        JSONArray array = new JSONArray(content.toString());
        for(int i = 0;i < array.length();i ++){
            JSONObject o = array.getJSONObject(i);
            result.add(new Strain(o.getString("id"),o.getString("sequences")));
        }
        return result;
    }
    
    public ArrayList<Virus> combiningData(ArrayList<DiseaseCharacteristic> list1,ArrayList<Strain> list2){
        ArrayList<Virus> result = new ArrayList<Virus>();
        for(Strain s:list2){
            int position = 0;
            for(int i = 0;i < list1.size();i ++){
                if(s.getId().equals(list1.get(i).getSequence_ID())){
                    position = i;
                    break;
                }
            }
            result.add(new Virus(
                    list1.get(position).getSequence_ID(),
                    list1.get(position).getSymptomes(),
                    list1.get(position).getMortality(),
                    list1.get(position).getComplications(),
                    list1.get(position).getDrug_Resistance(),
                    list1.get(position).getAt_Risk_Vulnerability(),
                    s.getSequences()
                    ));
        }
        
        return result;
    }
    
    public void outputVirusData(String filename,ArrayList<Virus> list){
        JSONArray array = new JSONArray();
        for(Virus v:list){
            array.put(new JSONObject(v));
        }
        
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(new File(filename)));
            writer.write(array.toString());
            writer.close();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    public void outputSameColumns(String filename,ArrayList<Strain> list){
        JSONArray result = new JSONArray();
        
        String[] stringList = new String[list.size()];
        //reading data
        for(int i = 0;i < list.size();i ++){
            stringList[i] = list.get(i).getSequences();
        }
        
        //put the column number into the result;
        for(int i = 0;i < stringList[0].length();i ++){
            char a = stringList[0].charAt(i);
            boolean isSame = true;
            for(int j = 0;j < stringList.length;j ++){
                char b = stringList[j].charAt(i);
                if(a != b){
                    //System.out.println("position:" + i + " a:" + a + " b:" + b);
                    isSame = false;
                    break;
                }
            }
            if(!isSame){
                result.put(i);
                //System.out.println(i);
            }
        }
        
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(new File(filename)));
            //System.out.println(result.toString());
            writer.write(result.toString());
            writer.flush();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    //will modify the content of list
    public void outPutStrainEmitted(String filename,ArrayList<Strain> list){
        ArrayList<Integer> result = new ArrayList<Integer>();
        
        String[] stringList = new String[list.size()];
        //reading data
        for(int i = 0;i < list.size();i ++){
            stringList[i] = list.get(i).getSequences();
        }
        
        //put the column number into the result;
        for(int i = 0;i < stringList[0].length();i ++){
            char a = stringList[0].charAt(i);
            boolean isSame = true;
            for(int j = 0;j < stringList.length;j ++){
                char b = stringList[j].charAt(i);
                if(a != b){
                    System.out.println("position:" + i + " a:" + a + " b:" + b);
                    isSame = false;
                    break;
                }
            }
            if(!isSame){
                result.add(i);
                System.out.println(i);
            }
        }
        
        for(Strain token:list){
            String newStrain = "";
            for(Integer i : result){
                System.out.println(i);
                newStrain += token.getSequences().charAt(i);
            }
            token.setSequences(newStrain);
            
        }
        
        JSONArray array = new JSONArray();
        for(Strain token:list){
            array.put(new JSONObject(token));
        }
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(new File(filename)));
            writer.write(array.toString());
            writer.flush();
        } catch (IOException e) {
            
            e.printStackTrace();
        }
    }
}
